URL: https://groups.google.com/forum/#!topic/rec.games.design/_G5o8h4VfiA
TITLE: PLEEEEEEEASE READ ME THIS TIME!!!!!!!!!!!!!!!!! 

----------------------------------------------------------------------------

Thursday, 28 April 1994 21:32:54 UTC+1 - Andrew Juell:
I wrote:
: First, I just talked with some people at FASA yesterday, and got
: permission to reproduce their Star Trek materials for non-commercial
: purposes.  I am working on a project, refurbishing the entire system,
: but I am missing a few books with critical data.  If anybody out there
: knows anybody who has any of the following, PLEASE have them contact
: me ASAP.  

: Ship Construction Manual (2nd edition)
: Gorn Ship Recognition Manual
: Orion Ship Recognition Manual
: Yacht Ship Recognition Manual
: TNG Officer's Manual (typo-free reprint)
: Errata sheets for any FASA Star Trek materials

First of all, there seems to have been some misunderstanding.
Apparently, I must have written permission from the legal departments
of both Paramount and FASA in order to make reproductions of any
copyrighted material for *any* purpose.  However, please tell me if
you have the books, because I'm still interested in buying them,
assuming you're willing to part with them.  I'm sorry if this error
caused any confusion.

--
_____________________________________________________________________
|   Andrew Juell   | Geek Code: GE/S d(?) p---(++)? c+ l?(-) u e(*) |
| tre...@imsa.edu <> |            m++ s+/+ n+(---) f !g(++) w++(+)    |
| (708)-907-5504   |            t++++(+) r(+) y?                    |
|-------------------------------------------------------------------|
|  "Things are only impossible until they are not."                 |
|                             -Picard, "When the Bough Breaks"       |
|  "Resistance is hopeless, number one."                            |
|                             -Picard, "Best of Both Worlds", Part 2 | 
|  "If there's nothing wrong with me, maybe                         |
|   there's something wrong with the universe."                     |
|                              -Dr. Crusher, "Remember Me"            |
|  "Captain, the Bajoran ship is disengaging."                      |
|  "Captain, we are receiving 285,000 hails."                       |
|                                -Lt. Crusher, "Parallels"              |
|___________________________________________________________________|
