URL: https://groups.google.com/forum/#!topic/rec.games.design/ORwHkflrDMs
TITLE: PLEEEEEEEASE READ ME THIS TIME!!!!!!!!!!!!!!!!! 

----------------------------------------------------------------------------

Tuesday, 26 April 1994 13:13:23 UTC+1 - Andrew Juell:
PLEEEEEASE read this all the way to the end.  I tried to post this
several times before, but either USENET barfed or else noone
responded.  Sorry about the crossposting, but I need as large an
audience as I can get.
DON'T JUST PRESS r!
Please only respond to this message via email to
tre...@imsasun.imsa.edu <>
because had to get someone else to post this for me...

First, I just talked with some people at FASA yesterday, and got
permission to reproduce their Star Trek materials for non-commercial
purposes.  I am working on a project, refurbishing the entire system,
but I am missing a few books with critical data.  If anybody out there
knows anybody who has any of the following, PLEASE have them contact
me ASAP.  

Ship Construction Manual (2nd edition)
Gorn Ship Recognition Manual
Orion Ship Recognition Manual
Yacht Ship Recognition Manual
TNG Officer's Manual (typo-free reprint)
Errata sheets for any FASA Star Trek materials

Thanks.  (WAIT!  I'M NOT DONE YET!)

While on the subject of the RPG, somebody posted here once about their
building a Gamemaster aid for FASA's ST:RPG.  Please mail me about
your progress.  I eagerly await the finished product.

I am also working on finalizing various areas of Treknology, both in
canon and non-canon terms.  First, I want to know if there is any way
to contact Sternbach and Okuda (authors of the Technical Manual)
through the Net.  I want to come up with OFFICIAL versions of those
warp equations printed in the manual.  Second, I am looking for
Treknologists who want to break the Star Trek mold and rewrite
Trekphysics the way it should be, but in much more intense detail:
right down to the advantages/disadvantages of different warp
geometries, etc.  Anyone who is interested in contributing please
email me so I can get some kind of group organized.  

Finally, does anyone have a recent version of the game "Tactical"?
I have version 5.29, but don't have a modem to get the latest version.
Does anyone out there have a better version or know where I can get
one on the Net? (I've checked archie)

Thank you for actually reading this all the way through.  All you have
to do now is respond, and you will have made me a very happy person.


--
_____________________________________________________________________
|   Andrew Juell   | Geek Code: GE/S d(?) p---(++)? c+ l?(-) u e(*) |
| tre...@imsa.edu <> |            m++ s+/+ n+(---) f !g(++) w++(+)    |
| (708)-907-5504   |            t++++(+) r(+) y?                    |
|-------------------------------------------------------------------|
|  "Things are only impossible until they are not."                 |
|                             -Picard, "When the Bough Breaks"       |
|  "Resistance is hopeless, number one."                            |
|                             -Picard, "Best of Both Worlds", Part 2 | 
|  "If there's nothing wrong with me, maybe                         |
|   there's something wrong with the universe."                     |
|                              -Dr. Crusher, "Remember Me"            |
|  "Captain, the Bajoran ship is disengaging."                      |
|  "Captain, we are receiving 285,000 hails."                       |
|                                -Lt. Crusher, "Parallels"              |
|___________________________________________________________________|
