URL: https://groups.google.com/forum/#!topic/rec.games.design/GxM9xE24e6o
TITLE: FUDGE: README 

----------------------------------------------------------------------------

Tuesday, 22 June 1993 00:01:16 UTC+1 - Andy Skinner:
Fsim - June 21, 1993
This is a simulator for FUDGE combat.  The program is by Andy Skinner,
FUDGE by Steffan O'Sullivan, et al.

    Fsim takes two characters from files (the defaults are fairly lame) and
runs them through a number of combats, keeping various statistics as it goes.
The default number of combats is 100, but this can be changed.

Compiling The Program
    If you have the Makefile, just type "make".  Otherwise, type
"cc -o Fsim Fsim.c".  If you get error messages (messages that just say
"Warning" might be OK), try switching some of the compiler-dependant defines
just after the comments at the top of the program.  Random number generators
and string comparison functions sometimes differ between operating systems.

Arguments
Usage of the simulator:
Fsim [options] [fighter1] [fighter2]
    -h  lists the arguments available to the program
    -n <number>  specifies the number of combats to be run, as in -n 1000
    -2  use coin flip method
    -6  use the standard 2d6 dice method, the default
    -10 use the 2d10 method
    -l  add bonuses to the trait; default for -6 dice method
    -r  add bonuses to the roll; default for -10 dice method
    -p  print out the characters first
    -v  verbose--a blow by blow account of the combat--use a small -n
        Note that the values for damage given will sometimes not add up
        because of constraints in the rules.
    -a  use the alternate opposed combat method--attack vs defense
    -d  <wound_level> sets the damage level which ends the combat
        wound_level is a string: Scratched, Hurt, Very Hurt, Incapacitated,
        Near Death, Dead
    -R  roll for damage in addition to calculated damage, as in FUDGE rules
        (default is calculated damage only)
    -R1 unofficial damage roll--add -4 to +4 roll, no constraints

[fighter1] and [fighter2] are input files for characters.  If one or both
of the characters are left undefined, a very boring default character will
be used for the undefined character[s].

Character File Format
    Characters can be changed by describing them in a text file.  The format
is multiple lines of headings, usually followed by values.  All text strings
may be upper or lower case or mixed.

First, what some of the arguments mean:
<level> means either one of the following strings:
    terrible
    poor
    mediocre
    fair
    good
    great
    superb
    legendary
or a number value from -3 to 4, -3 meaning terrible and 4 meaning legendary.

<bonus> is the bonus to damage by weapon size and sharpness
    +0 for no weapon, no Martial Art skill.
    +1 Martial Art skill at Fair or better, no weapon.
    +1 for small weapon (knife, etc.)
    +2 for average-sized weapon (sword, axe, spear, bow, etc.).
    +3 for large weapon (polearm, battleaxe, etc.).
    +1 for sharp weapon (additive with other weapon damage).

<alevel> is the amount the armor affects damage
    -1 or -2 for a good shield (additive with other armor). (Note: a
        -2 shield is *very* large and cumbersome to carry.)
    -1 for light, pliable non-metal armor.
    -2 for heavy, rigid non-metal armor
    -2 for light metal armor.
    -3 for medium metal armor.
    -4 for heavy metal armor.
    -5 or more for SF advanced armor.


Headings
scale <number>                                scales Fair of Strength and mass
strength <level>                        adds to damage done with weapon
mass <level>                                subtracts from damage done to you
                                        mass does not vary much within a
                                        race or species, Mediocre to Good
damage_capacity <level>                        determines wound levels
skill <level>                                weapon skill
weapon <bonus>                                damage bonus for weapon, size and sharp
armor <alevel>                                level or armor being worn
shield <number>                                shield level: 0, -1, -2
                                            don't use this if added into armor
bonus <bonus>                                a bonus added to skill, using method
                                            as discussed above concerning
                                            the -r and -l flags
initiative <level>                        level of initiative trait, used at
                                            beginning of alternate combat
knockout                                if present, use knockout damage

Any lines which don't begin with one of these headings is ignored, so you
can have comments.


Output

    Most outputs are given in percentages.  "+0" represents a number that
rounds to 0 when determined as a percentage, but which was really non-zero.

    After running the given number of combats, stats are printed out.  First,
the percentage of combats won by each fighter is printed out.  Then the
percentage of times each fighter won or lost a combat at each damage level
is shown.  For instance, out of 10 combats, fighter A won 4 and lost 6.  Of
the combats he won, he finished up at Well twice, Scratched once, and Hurt
once.  Of the combats he lost, he finished up Dead twice, Near Death three
times, and Incapacited once.  The double bar shows the ending damage level
(normally Incapacitated, but set by "-d").  Wound levels to the left of the
double bar show the percentage of wins per fighter at each wound level.  Wound
levels to the right show the percentage of losses per fighter at each wound
level.

    The percentage of the time that the fighter who drew first blood (caused
non-zero damage) wins is presented, as is the percentage of the time that
the fighter wins who first takes his opponent to Hurt damage level or worse.

    Next Fsim prints the number of misses, hits, and attempts each fighter
made.

    Then Fsim prints the percentage of hits that caused 0, 1, 2, ... points
of damage.  0 represents completely absorbed blows, and 17 is the maximum,
as the number of wound levels for Max Damage Capacity.  The numbers are
percentages of hits, given on the previous line.

    If the "-a" method is used, a fighter can lose blows.  The percentage
of combats in which the fighter lost a blow is printed, if any.

    Finally, Fsim prints the percentage of combats that went 1, 2, ... rounds,
and the number of combats that had 1, 2, ... hits during the combat.

Suggestions welcome, though I will probably only implement any that seem
useful and do not require too much rewriting of the current system.

andy skinner
ski...@stdavids.picker.com <>
