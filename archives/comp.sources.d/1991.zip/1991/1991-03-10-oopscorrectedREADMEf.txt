URL: https://groups.google.com/forum/#!topic/comp.sources.d/KLbRyIv_flM
TITLE: oops! - corrected README file for 'policy' package 

----------------------------------------------------------------------------

Sunday, 10 March 1991 02:56:56 UTC - Bud Hovell @ Mtek:
Nuts! I just mailed r$alz an update to fix an egregiously stupid
statement made by me in the last paragraph of the README file
included in the 'policy' package.
In a phone conversation, I just heard that it is *already* out on
the net! :-O

What amazes me is that I just sent it to him a few days ago - I
had expected to cover my error without anyone (except Rich) knowing
about it, since it (supposedly) takes weeks for stuff to get into
the archives and get posted. So much for relying on net.rumors(TM).

Anyhow, the README below attached is a bit more explicit and corrects
the terminally-dumb statement (hopefully without introducing others :-).

Bud Hovell
____________
b...@mtek.com <>
"Retribution rides a slow horse, but seldom falters." - unattrib.

------------ cut ----------------------------- cut ------------

$Id: README,v 1.12 91/03/09 12:01:04 bbh Rel $

What is in this package and how to use it:
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
The file '1stlogin.ann' (first-login annnouncement) is something we call
from /etc/profile by adding this entry:

   if [ -r /usr/local/etc/1stlogin.ann -a ! -f $HOME/... ]
   then . /usr/local/etc/1stlogin.ann
   fi

...which tests to see if the '...' file exists in the user's home 
directory, and presents him with the announcement if it does not. This
assures that every new user, on first login, gets the instructions 
regarding his responsibility to read, understand, and comply with local
policy. It directs him to the use of the 'policy' command to become
and stay current on in-house policy. You may choose to use it or not.
If you do, this file should be set to make it read-only (say, 444).

All other files listed in the MANIFEST relate to the 'policy' script
itself, or to the example policy text files it might call:

Much of the 'gen' file was outright lifted directly from the text of a
similar file used in one of the Canadian universities - have since for-
gotten who/where was responsible (if someone can tell me, I'd be most
grateful so I can give proper attribution for the original version).  We
have made a number of changes for local circumstances.  You may wish to
start with this as a template for your own general policy statement.

A few other text files are provided simply as examples of supplementary
policy descriptions. Because I tend to be a hard-ass, they probably won't
be appropriate at your site, but the subjects may be some you wish to cover.

The executable file, 'policy', should be useful to you even if you decide
to drop-kick the use of our example policy files, since it provides an easy
way to manage a full screen of policy-file listings for selection by the
user. If you make improvements on this script, I'd sure like to see them
so they can be incorporated into future revisions, with proper credit to
you for the contribution. Since I don't claim to know about all the various
unixen out there (remember, I'm a 'suit', not a 'tech' :-), this script
may need minor modification for some non-sysV machines. So far, though, I
haven't gotten any complaints, so it must be working with most.

Installation: you must create the policy directory, by default named 'Policy',
and within that directory an empty menu file, by default named 'polmenu',
which must be set mode 666 (read and write for everyone). The directory also
will contain the individual policy text files (set read-only) that you may
create. See the instructions in the 'policy' script for more info, if this
isn't fully clear.

Then, of course, you will want to put the 'policy' script in some bin
location accessible to everyone and set to an appropriate mode, say 755,
owner and group 'bin' or 'root'.

That should do it.

Once set up, the script automatically updates the menu any time a new text
file is added.  NOTE: in those instances that you may choose to *remove* a
named text file, just touch the menu file back to an ancient date (e.g.,
"touch 0101000080 polmenu") and 'policy' will faithfully rebuild a new
menu of current entries when next invoked by any user.

Hope this is useful to your purposes...bud@mtek.com <>
