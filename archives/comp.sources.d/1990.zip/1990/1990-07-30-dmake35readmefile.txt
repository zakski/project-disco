URL: https://groups.google.com/forum/#!topic/comp.sources.d/U0vbQ-0WWpE
TITLE: dmake 3.5 _readme file. 

----------------------------------------------------------------------------

Monday, 30 July 1990 00:32:10 UTC+1 - Dennis Vadura:
Here is the _readme file for the recently posted 21 part posting of dmake.
I goofed in not making sure it was at the start of the shar file.  Sorry for
any inconvenience.  Sources are in comp.sources.misc or available for ftp
from watmsg as noted below.
-dennis
----
This is the first distribution of dmake version 3.5.  dmake is a
make like tool that has been written by me and has been used by individuals at
the University of Waterloo for about a year and a half now.  I feel it has
matured enough to be made available on a wider scale.

dmake is available for anonymous ftp from watmsg.uwaterloo.ca <http://watmsg.uwaterloo.ca> address is
129.97.129.9.  It is in the pub/src directory, set your mode to binary,
and copy either:

        dmake-3.5.tar.Z                - compressed tar format
        dmake-3.5.zoo                - zoo archive

dmake is different from other versions of make in that it supports significant
enhancements (See the man page).  A short summary of the more important
ones follows:

        . support for portable makefiles
        . runs on many platforms (DOS, generic unix [sysv and bsd4.3],
          apollo, and others)
        . significantly enhanced macro facilities
        . transitive closure on inference graph
        . sofisticated inference algorithm
        . support for traversing the file sytem both during making of targets
          and during inference
        . %-meta rules for specifying rules to be used for inferring
          prerequisites
        . highly configurable
        . support for libraries
        . parallel making of targets on architectures that support it
        . attributed targets
        . text diversions
        . group recipes

All code found in this distribution is original and writen by me except where
noted in the source and the following:

- dbug package from Fred Fish  (dmake DEBUG=1, to make a debugging version
  of dmake)

- malloc.c package, came from the net originally, author name wasn't
  on it when I found it, I can't even remember where I got it.

-dennis
-- 
--------------------------------------------------------------------------------
To fight sexism, you need MORE sexism!  Or at least| Dennis Vadura
that is the way the world appears to work.         | dva...@dragon.uwaterloo.ca <>
================================================================================
